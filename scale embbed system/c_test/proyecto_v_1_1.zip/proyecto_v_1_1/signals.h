#ifndef SIG_H
#define SIG_H

void ini_senales();
void manejador( int sig);

#endif