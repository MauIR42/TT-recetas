#ifndef HILO
#define HILO

void * funHilo( void * arg );

#endif