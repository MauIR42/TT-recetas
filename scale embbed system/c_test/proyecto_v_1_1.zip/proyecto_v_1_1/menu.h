#ifndef MENU_H
#define MENU_H

struct node* create_menu();
struct node* read_menu(char * file, struct node *file_father);
enum ButtonStates delay_debounce(enum ButtonStates button_state, int button);

#endif
